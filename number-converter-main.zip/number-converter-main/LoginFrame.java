import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LoginFrame extends JFrame implements ActionListener {

    JLabel title, userLabel, passLabel;
    JTextField userField;
    JPasswordField passField;
    JButton loginButton, cancelButton;

    public LoginFrame() {
        super("Login");
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300, 200);
        this.setLayout(null);
        this.getContentPane().setBackground(Color.GRAY); // set background color
        initialiseObjects();
    }

    public void initialiseObjects() {
        Font font = new Font("Arial", Font.PLAIN, 18);

        title = new JLabel("Login");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(110, 20, 80, 30);
        add(title);

        userLabel = new JLabel("Username:");
        userLabel.setFont(font);
        userLabel.setBounds(20, 60, 100, 25);
        add(userLabel);

        userField = new JTextField(20);
        userField.setFont(font);
        userField.setBounds(120, 60, 150, 25);
        add(userField);

        passLabel = new JLabel("Password:");
        passLabel.setFont(font);
        passLabel.setBounds(20, 90, 100, 25);
        add(passLabel);

        passField = new JPasswordField(20);
        passField.setFont(font);
        passField.setBounds(120, 90, 150, 25);
        add(passField);

        loginButton = new JButton("Login");
        loginButton.setFont(font);
        loginButton.setBounds(60, 130, 80, 30);
        loginButton.addActionListener(this);
        add(loginButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setFont(font);
        cancelButton.setBounds(150, 130, 90, 30);
        cancelButton.addActionListener(this);
        add(cancelButton);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String user = userField.getText();
            String pass = String.valueOf(passField.getPassword());

            if (user.equals("admin") && pass.equals("admin123")) {
                new SwingConverter();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == cancelButton) {
            this.dispose();
        }
    }

    public static void main(String[] args) {
        new LoginFrame();
    }
}
